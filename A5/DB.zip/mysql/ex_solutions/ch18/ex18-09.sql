GRANT SELECT, INSERT, UPDATE
ON ap.*
TO dorothy@localhost IDENTIFIED BY 'sesame'